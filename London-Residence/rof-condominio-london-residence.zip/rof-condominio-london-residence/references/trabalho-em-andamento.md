# ATUALIZAÇÃO 25/11/2026 — ler primeiro
**Pedido "vamos atualizar a prestação de contas":** seguir `London-Residence/scripts/COMO_ATUALIZAR.md` no repositório `rofcontabilidade/meus-projetos` (branch `claude/trusting-bell-rnp4so`). Os programas que geram o Excel (`build.py`, `extra.py`, `classify.py`, `parse.py`, `interno.py`) e os lançamentos do razão (`dados/lanc.json`) estão nessa pasta; basta trocar os números de novembro e rodar.
Resumo completo e atualizado em `ANOTACOES_London_Residence.md` no repositório GitHub `rofcontabilidade/meus-projetos`, pasta `London-Residence/` (branch `claude/trusting-bell-rnp4so`), junto com a prestação de contas (Excel e PDF), o relatório interno de divergências, a curadoria do regimento e a ata de 03/06/2026.
- Prestação 12/2025–11/2026: receitas 164.775,87; despesas 177.851,97 (pintura 74.100); resultado −12.559,02; saldo 28.551,82; inadimplência 280,54. Extratos × AcolWeb conciliados nos 12 meses (só falta o extrato após 19/11: R$ 1.413,22 + Copel 603,91).
- Divergências de cadastro (7 itens) só no relatório interno; a prestação mostra apenas "saldo conciliado".
- Fidelidade Drywall: pintura da garagem R$ 25.000 (aprovado 20.000) — igual ao orçamento nº 28 da Santos Aleluia (fachada 48.000 + garagem 25.000, de 21/11/2025).
- Fundo de pintura pela planilha da Rosangela (aba "Conciliado", 24/11): arrecadado 05/2023–10/2026 = R$ 81.000; saldo após a pintura = −R$ 3.950. Corrigir na prestação o "saldo do fundo R$ 3.451,61".
- Ata da AGE 03/06/2026 localizada; não haverá ratificação. Lacunas do regimento: `alertas.md` item 1-B.
- Cobrança judicial após 3 taxas: não há ata com essa regra (AGO 22/12/2022, 2º assunto = tolerância de 3 meses).

# TRABALHO EM ANDAMENTO — London Residence (parado em 19/11/2026)

> **Ao retomar:** ler este arquivo inteiro antes de qualquer coisa. Perguntar à Rosangela o que mudou desde 19/11 (a AGO de 26/11/2026 já terá acontecido) e pedir a ata dela.
> Conforme cada item for resolvido, marcar ✔ com data e mover a informação definitiva para `SKILL.md`, `atas.md`, `alertas.md` ou `unidades.md`.

---

## 1. Onde estão os arquivos

| O quê | Onde | ID no conector Google Drive |
|---|---|---|
| Pasta do London (conta ROF, unidade G:) | `G:\Meu Drive\Trabalho ROF\London Residence` | `1JP10RwRC7AqkCw5ETX4c1TEvWR3jRg6k` |
| Pastas mensais 2026 (relatórios AcolWeb, extratos) | `Diversos/2026/MM_2026` | pasta 2026: `1fPVv1F7a4xMPZ8z-OcYg8GxTUQOcB0DX` |
| Pasta 11_2026 (extrato Sicredi até 19/11) | `Diversos/2026/11_2026` | `160wJuzmV0VzOt7mN1GNyQdG1wQiTsBX_` |
| **Despesas 2026** (notas fiscais, comprovantes, boletos por mês) | Drive da conta do condomínio (unidade H:), **compartilhada como leitor** com a conta da ROF em 19/11/2026 | `1XLGymhDB98YchrQGKSn4xJ0unlaY4Ntz` |
| Despesas 2025 | idem, compartilhada para histórico | procurar em "Compartilhados comigo" |
| Planilha do fundo de pintura (original) | `Diversos/Fundo de Pintura.xlsx` (atualizada 01/12/2025) | `1qJo4hwpmRNEkWwd-94oGFKKJwqsTZQGK` |
| Contrato da pintura (Santos Aleluia) | `DOC's.../Contrato de Prestação de Serviços/Contrato de Prestação de Serviços - PINTURA.pdf` | `1gjR1z8yhChKyXewZyBwl518EydkYtfCA` |
| Proposta de pintura 2026 | `Declarações.../Recibo de pagamento/PROPOSTA DE PINTURA_2026.pdf` | `1tkvYv3JdYGcWsfMzuqTs_wLLD2kXYZJ1` |
| Edital da AGO 26/11/2026 | `DOC's.../Edital Lista de presença/Edital de Convocação 11.2026.pdf` | `1tr0HsP42QLhkga8pxuf32ykVG7EGH7id` |
| **Roteiro da AGO** (feito nesta sessão) | repositório: `London-Residence/Roteiro_AGO_26-11-2026.docx` | — |
| **Validação do fundo de pintura** (feita nesta sessão) | repositório: `London-Residence/Validacao_Fundo_Pintura_2023-2026.xlsx` | — |

- A conta do condomínio no Google (unidade H:) é a do e-mail do próprio condomínio (londonresidencefrg). Esta sessão **não acessa o H:**; o acesso é só pelo que for compartilhado com a conta da ROF.
- O sistema de gestão é o **AcolWeb** (Group Software). **Não temos acesso direto**: a Rosangela exporta os relatórios e salva no Drive.
- ⚠️ A planilha `Despesas 2026/Prazo dos boletos.xlsx` tem **logins e senhas em texto aberto** (TK Elevadores, Direct Internet, boleto AcolWeb). Recomendado retirar. Nunca copiar essas senhas para lugar nenhum.

---

## 2. Assembleia Geral Ordinária de 26/11/2026

Pauta do edital (17/11/2026): A) portaria com reconhecimento facial; B) prestação de contas 2026; C) eleição de síndico.

Entregue: roteiro com o **texto original** de cada documento e redação proposta para a ata (itens A, B, C, C2 inadimplência, D a G).

Itens D a G (ratificação do regimento de 06/2026, pets de inquilinos, errata da ata de 2025, pedestre no portão) **dependiam de edital complementar até 21/11/2026**. → Ao retomar: perguntar se o edital complementar saiu e o que foi votado.

**Regra de cobrança judicial** pedida pela Rosangela: está na **AGO 22/12/2022, 2º assunto** — "tolerância de 03 (três) meses de inadimplência e depois tomar uma medida mais incisiva de cobrança"; ação de execução só foi prevista expressamente para os débitos existentes em 12/2022. Proposta de redação expressa ("3 taxas em aberto → execução, CPC 784 X") está no roteiro, item C2.

Correção feita: o **regimento** se altera por **maioria dos presentes** (Conv. art. 14 caput; CC 1.351 após a Lei 10.931/2004 exige 2/3 só para a convenção). O problema do regimento de 06/2026 é apenas a ata não estar no Drive.

Pendente após a AGO: registrar a nova ata em `atas.md` (novo síndico, conselho, portaria facial, regra de inadimplência, o que mais for aprovado) e atualizar `SKILL.md`.

---

## 3. Prestação de contas 2026 — o que já está levantado

### Saldos da conta principal (Sicredi 61921-3), pelos relatórios mensais do AcolWeb
| Data | Saldo |
|---|---|
| 31/12/2025 | R$ 8.838,40 (balancete anual 2025) · aplicação R$ 33.630,87 · fundo de reserva R$ 284,50 · total R$ 42.753,77 |
| 31/01/2026 | R$ 9.651,52 (saldo inicial do relatório de 02) |
| 28/02/2026 | R$ 11.600,33 |
| 31/03/2026 | R$ 5.920,70 |
| 30/04/2026 | R$ 6.330,68 |
| 31/05/2026 | R$ 9.757,23 |
| 30/06/2026 | R$ 7.571,72 |
| 31/07/2026 | R$ 3.294,44 |
| 31/08/2026 | R$ 5.111,63 |
| 30/09/2026 | R$ 8.864,03 (saldo inicial do relatório de 10) |
| 31/10/2026 | R$ 12.210,33 ✔ bate com o extrato Sicredi |
| 19/11/2026 | **R$ 26.789,03** (extrato Sicredi). Débito agendado: Copel R$ 603,91 em 26/11 |

Movimentos da poupança integrada identificados em 2026: resgate R$ 15.000 (18/02), aplicação R$ 5.600 (25/03), transferência R$ 10.000 (31/03), resgate R$ 4.508,66 (07/04). Janeiro sem relatório (provável resgate para a 1ª parcela da pintura).

### Novembro/2026 (extrato até 19/11) — lançamentos explicados pela Rosangela
- **06/11 – PIX de R$ 13.279,29 do escritório do advogado (Everton Soares)** = recebimento do **apto 210** (débito com multa, juros e encargos). Na prestação de contas: "recuperação de inadimplência", não receita do mês. Confirmar se os honorários já vieram descontados.
- **11/11 – PIX R$ 2.427,00 para Asset Solution** = **compra do motor do portão**. NF-e 567 de 11/11/2026 = **R$ 2.027,00** (kit motor R$ 1.889,50 + cremalheira R$ 137,50). Diferença de **R$ 400** — provável instalação, falta nota de serviço. Dentro do limite do síndico (2 salários mínimos = R$ 3.242; Conv. art. 17 § ú "e").
- Demais de novembro: HDI 317,77; chaveiro 12,00; Sanepar 1.975,95; ROF 486,30; síndico 1.621,00; zeladora 865,00; Direct 109,90; TK 427,25; DARF retenção TK 20,83; Dedetizadora VIP 500,00; Group 208,31; jardinagem L.A. 450,00; recebimentos por cobrança simples e PIX.
- A Rosangela vai **lançar no AcolWeb os PIX de novembro** que não baixam sozinhos, antes de tirar os relatórios.

### Outras despesas de 2026 a explicar na assembleia
- Asset Solution: troca de câmeras e fiação (entrada + 3 parcelas de R$ 610,30, 06 a 08/2026), controles do portão R$ 109 (08/2026), controlador de acesso e visita técnica R$ 1.050 (10/2026), motor R$ 2.427 (11/2026).
- Fidelidade Drywall (ver fundo de pintura), telhas R$ 455 (08/2026), playground R$ 750 (08/2026), remoção de vespas R$ 500 (10/2026), assessoria jurídica R$ 1.621 (04/2026) e R$ 1.000 (06/2026).

---

## 4. Fundo de pintura — validação (planilha `Validacao_Fundo_Pintura_2023-2026.xlsx`)

**Entradas previstas pelas atas (20 unidades):**
| Período | Base | Previsto |
|---|---|---|
| 05–11/2023 a R$ 45 | AGE 20/03/2023, 6º assunto (R$ 900/mês do Lucas vira fundo de pintura) | R$ 6.300 |
| 12/2023 a R$ 70 | AGO 30/11/2023, 9º assunto ("a partir da competência de dezembro de 2023") | R$ 1.400 |
| 01/2024–11/2025 a R$ 70 | idem | R$ 32.200 |
| 12/2025–03/2026 a R$ 70 (fachada) | AGO 01/12/2025, 7º assunto | R$ 5.600 |
| Extra 03/2026 R$ 520 | idem | R$ 10.400 |
| Extras 05 e 06/2026 R$ 500 | idem (estacionamento) | R$ 20.000 |
| 04–11/2026 a R$ 70 (corredores) | idem | R$ 11.200 |
| **Total** | | **R$ 87.100** |

Planilha original da ROF: R$ 39.400 até 11/2025 (usa R$ 45 em 12/2023 → **R$ 500 a menos** que a ata). A 2ª coluna dela (R$ 34.500: R$ 900/mês até 12/2024 e R$ 1.500/mês em 2025) **não bate com nenhuma ata** — perguntar a origem.

**Saídas:**
| Data | Fornecedor | Obra | Valor | Situação |
|---|---|---|---|---|
| 05, 06 e 10/2024 | (planilha ROF) | muros/portão (AGE 21/03/2024) | R$ 10.850 | conferir nos relatórios de 2024 |
| 01/2026 | Santos Aleluia (CNPJ 41.208.537/0001-29) | fachada | R$ 10.000 | NFS-e 17 |
| 18/02/2026 | Santos Aleluia | fachada | R$ 15.000 | NFS-e 19 |
| 13/03/2026 | Santos Aleluia | fachada | R$ 5.000 + R$ 5.000 | NFS-e 23 e 24 |
| 31/03/2026 | Santos Aleluia | fachada | R$ 8.000 | NFS-e 27 |
| 06/04/2026 | Santos Aleluia | fachada | R$ 4.500 | NFS-e 28 |
| 30/03/2026 | Fidelidade Drywall | ? ("colocar descrição") | R$ 1.680 | a confirmar |
| 25/05/2026 | Fidelidade Drywall | "pintura predial" (estacionamento ou corredores?) | R$ 6.000 | sem NF |
| 16/06/2026 | Fidelidade Drywall | pintura estacionamento | R$ 10.000 | sem NF |
| 10/07/2026 | Fidelidade Drywall | pintura estacionamento | R$ 9.000 | sem NF |
| 26/08/2026 | Tintas Verginia | material – tinta Dacar | R$ 1.600 | sem NF |
| 08/05/2026 | Mercado Pago / Leandro Gutoski (MEI) | ? | R$ 114,42 + R$ 24,00 | a confirmar |
| **Total lançado** | | | **R$ 86.768,42** | confirmados: R$ 74.100 |

**Conclusões e perguntas abertas:**
1. Entradas previstas (R$ 87.100) ≈ saídas (R$ 86.768,42): fundo praticamente zerado, antes de rendimentos e inadimplência.
2. Fachada: contrato de **R$ 45.000** (14/01/2026; 10.000 de entrada "para compra de materiais" + 15.000 em 18/02 + 10.000 com 80% + 10.000 no fim; tinta emborrachada, 2 tons) × pago **R$ 47.500** → **R$ 2.500 acima do contrato** (dentro dos R$ 48.000 aprovados). Houve aditivo?
3. **Fidelidade Drywall: R$ 26.680 sem NF e sem contrato** localizados. Separar estacionamento (aprovado R$ 20.000) × corredores (R$ 11.200).
4. Corredores: nenhum lançamento com esse histórico. Foi feito?
5. Material fora do contrato: só a tinta de R$ 1.600 identificada.
6. Saldo do fundo em 30/11/2025 pela planilha (R$ 28.550) × aplicação real (R$ 33.391,58): diferença de R$ 4.841,58 (rendimentos? outros valores na poupança?).
7. O **recebido real** do fundo não aparece nos relatórios mensais: quase todas as unidades pagam o fundo **dentro do boleto da taxa**. Só aparecem em linha separada a Luciane (4 unidades) e o apto 308.

---

## 5. Alertas fiscais (para a contadora avaliar antes de apresentar)
- **INSS 11% não retido** nas NFS-e da Santos Aleluia (código 07.02, construção civil por empreitada, Simples Nacional; Lei 8.212/91 art. 31; IN RFB 2.110/2022). O condomínio responde solidariamente. Verificar também as notas da Fidelidade Drywall quando aparecerem.
- **NFS-e 23** com local de prestação e de incidência do ISS em Araucária. Em obra de construção civil, o ISS é devido no local da obra (LC 116/03, art. 3º, III), Fazenda Rio Grande.
- Retenção da TK Elevadores (CSRF) é recolhida todo mês por DARF (no extrato: "DEBITO ARRECADACAO DARFC0385") — ok.

---

## 6. Relatórios pedidos à Rosangela (AcolWeb e banco)
1. **Extrato de Contas (Entradas e Saídas)** de 01/2026 e 09/2026 (faltam no Drive) e de 01/11/2026 até a data de corte (depois de lançar os PIX).
2. **Demonstrativo detalhado – regime caixa** de 01/01/2026 até a data de corte (o mesmo formato do balancete 2025). Se possível, 2023 e 2024 só da conta de pintura.
3. **Movimentação da Aplicação Financeira / Poupança Integrada** de 05/2023 até hoje, ou o extrato da poupança no Sicredi.
4. **Relatório de inadimplência detalhado** na data de corte.
5. Relatório que mostre a **composição do boleto por item** (taxa, fundo de reserva, fundo de pintura, extra) por competência, para apurar o fundo de pintura efetivamente pago.
6. Documentos: notas e orçamento/contrato da **Fidelidade Drywall**, nota da **Tintas Verginia**, nota de serviço da instalação do motor (R$ 400).

## 7. Próximos passos
1. Receber os relatórios → conferir mês a mês relatório × extrato Sicredi.
2. Fechar o fundo de pintura com o recebido real e atualizar a planilha de validação.
3. Montar a **prestação de contas 2026**: resumo de 1 página, quadro mensal, saldos por conta, inadimplência (valor e nº de unidades, sem nomes), obras, orçamento 2027 e redação da ata.
4. Registrar a ata da AGO de 26/11/2026 na skill.
