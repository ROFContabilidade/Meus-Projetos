# ALERTAS — conflitos, riscos e pendências do London Residence

Levantamento feito em 19/11/2026 sobre os documentos do Drive. Ao responder qualquer pergunta que toque estes temas, **mencione o alerta** e recomende o caminho seguro. Quando um alerta for resolvido, marque ✔ com data.

## 1. ✔ Ata da AGE de 03/06/2026 localizada (25/11/2026) — observações de forma (BAIXA)
Ata recebida junto com a curadoria do Dr. Everton. Aprovação por maioria dos presentes (Conv. art. 14; Reg. art. 72; CC 1.354-A admite assembleia virtual). A Rosangela decidiu **não ratificar**; registrar só para conhecimento:
- convocação 2 dias antes (Conv. art. 6º § 3º pede 5; § 4º só com urgência comprovada);
- sem presidente/secretário; 3 presentes não assinaram (Conv. art. 16);
- Neli (304) tinha confissão de dívida em 06/2026 — se em atraso em 03/06, não votaria (art. 8º § 3º); Elimir votou pelo 306 (proprietária Viviane) sem procuração mencionada (art. 9º); mesmo assim a maioria se mantém;
- a ata não anexa o texto final dos 75 artigos (necessário para registro no RTD);
- grafias "Kevin Wendryu Fogaça" / "Maria Neusa Vernick" diferem do cadastro;
- a ata tem CPFs: distribuir aos moradores só cópia sem CPF (LGPD).

## 1-B. Lacunas do Regimento 2026 frente ao de 2021 (curadoria do Dr. Everton, 25/11/2026) (MÉDIA)
A curadoria (cópia no repositório `London-Residence/Curadoria_Regimento_Dr_Everton_25-11-2026.pdf`) mostra onde cada regra de 2021 está hoje; ~85% tem base firme. **Sem base específica hoje:**
1. Playground (só moradores/visitantes, brinquedos até 10 anos, menor de 5 com responsável) — arts. 14, 24 e 31 não cobrem.
2. Vaga cedida a hóspede com aviso de placa/veículo/condutor — arts. 33 e 54 não exigem.
3. Gás fechado em viagem, torneiras, limpeza de sacada só com pano — só dever geral (Conv. 5º f e 29): cobra o dano, não pune a conduta.
4. Padrão do fechamento de sacada — art. 21 § 1º remete a padrão da assembleia ainda não aprovado (o de 2021 era vidro verde e perfil branco).
5. Posição do condensador (art. 18) e material/cor da basculante (art. 21) — dependem de deliberação.
6. Porte de animais e tela para gatos — perdidos.
7. Prazo de defesa de 5 a 10 dias úteis — vem de "Orientações jurídicas de 30/03/2026", documento não deliberativo.
- **Multa:** o Reg. art. 60 pune infração "deste Regimento"; regras só da Convenção/ata devem ser enquadradas também num artigo do regimento (pedestre → 53; vaga → 33/37; roupas → 12; lixo → 47–52). Nas lacunas 1, 2, 3 e 6: notificar, mas multa é frágil.
- Encaminhamento: deliberações simples de assembleia (maioria dos presentes) para sacada, playground, aviso de vaga cedida e ar-condicionado (curadoria, item 5).

## 1-A. Regra de cobrança judicial
A AGO 22/12/2022 (2º assunto) fixou tolerância de 3 meses e "medida mais incisiva", sem dizer expressamente "execução a partir da 3ª taxa" (a execução só foi prevista para os débitos de 12/2022). Proposta de redação expressa no roteiro da AGO 26/11/2026, item C2.

## 2. Mandato anual do síndico (AGO 01/12/2025, 4º assunto) (ALTA)
A Convenção (art. 17) fixa mandato de **2 anos** (máximo legal: CC 1.347). Mudar para 1 ano é **alteração da convenção** → **2/3 dos condôminos** (Conv. arts. 14 § ú "a" e 39; CC 1.351) e deveria constar expressamente da ordem do dia. Votaram 9 de 20 unidades.
- Situação prática: a AGO de 26/11/2026 já pauta "eleição de síndico", tratando o mandato como anual. Uma eleição anual é defensável (o síndico pode renunciar/ser reconduzido), mas a **alteração da convenção não está formalizada**.
- Ação: incluir em pauta "alteração do art. 17 da Convenção" e colher 2/3 (assinaturas inclusive fora da assembleia), depois registrar no RI.

## 3. Valor da multa: R$ 300 (AGE 01/2026) × 1 taxa condominial (Reg. 2026) (MÉDIA)
O Reg. 2026 é posterior e revoga o contrário (art. 75) → vale **advertência escrita na 1ª infração** e **multa de 1 taxa condominial** na reincidência ou infração grave (arts. 61–62). Os R$ 300 valem só para fatos de 12/01/2026 a 02/06/2026.
- Atenção: o Reg. 2021 (art. 60) permitia multa **sem advertência**; o Reg. 2026 exige **advertência antes**, salvo infração grave (ex.: art. 59, portão).

## 4. Animais e inquilinos (MÉDIA)
- Convenção art. 5º "m": proíbe manter animais nas unidades (cláusula genérica).
- Reg. 2026 Cap. VII/art. 38: permite animais domésticos com regras.
- AGO 12/2025, 6º assunto: "**Inquilinos não estão permitidos a ter PET**".
- STJ (REsp 1.783.076/DF, 2019): é inválida a proibição genérica de animais; só se restringe animal que cause risco à segurança, higiene ou sossego. Discriminar inquilino × proprietário também é frágil (o locatário tem os mesmos direitos de uso — CC 1.335 e Lei 8.245/91).
- Recomendação: **não multar pela simples existência do pet**; agir pelo art. 38 (guia, fezes), art. 26 (elevador), arts. 17/27 (barulho) e art. 8º (salubridade/odor).

## 5. Juros e multa de atraso (MÉDIA)
O Reg. 2021 previa juros de 3% a.m. e multa de 4% — ilegal (CC 1.336 § 1º). O Reg. 2026 não trata do tema. **Usar a Convenção: 1% a.m. + correção pró-rata + multa de 2%** (arts. 36 e 40). Conferir o cálculo da planilha `MULTA E JUROS.xlsx` (usa "multa de 1%" e juros de 1% a.m. pro rata).

## 6. Quóruns de instalação nos editais (BAIXA)
Os editais dizem "presença de pelo menos a metade dos condôminos" na 1ª convocação; a Convenção (arts. 11 e 12) exige **2/3 das unidades**. Na prática a 2ª chamada (qualquer número) resolve, mas corrigir o texto dos editais.

## 7. Envio das convocações e das deliberações (BAIXA)
Convenção: convocação por **carta registrada ou protocolada** (art. 6º) e deliberações afixadas em 8 dias e enviadas a todos (art. 15 § ú). Se o envio é só por WhatsApp/e-mail, guardar comprovante de entrega (protocolo ou print de leitura) de cada unidade.

## 8. Portaria com reconhecimento facial (pauta 26/11/2026) (MÉDIA)
- Biometria facial é **dado pessoal sensível** (LGPD art. 5º II e art. 11): precisa de base legal, finalidade, política de retenção e alternativa para quem não consentir; contrato com o fornecedor como operador (art. 39).
- Contratação/obra nova em área comum: verificar se é benfeitoria **útil** (maioria dos condôminos, CC 1.341 II) — a Convenção art. 14 § ú "c" fala em unanimidade para benfeitorias, mas o CC prevalece; registrar na ata o quórum e o orçamento.
- Despesa acima de 2 salários mínimos exige aprovação da assembleia (Conv. art. 17 § ú "e").

## 9. Erro de data na ata da AGO 2025 (BAIXA)
O texto diz "primeiro dia do mês de novembro de 2025"; a assembleia foi em **01/12/2025** (convocação de 24/11). Fazer errata/retificação na próxima ata.

## 10. Proibição de Airbnb (BAIXA — favorável)
Reg. 2026 art. 5º + AGE 01/2026. O STJ (REsp 1.819.075/RS, 2021) admite a proibição quando a convenção prevê destinação residencial — a Convenção do London fala em "mesma destinação que tem a edificação" (art. 5º "f") e unidades residenciais (art. 3º). Para blindar, incluir a vedação expressa numa futura alteração da Convenção (2/3).

## 11. Pedestre no portão de carros (BAIXA)
O Reg. 2026 não repetiu a proibição do art. 16 do Reg. 2021. Continua valendo a deliberação da AGO 2021 (7º assunto) e o art. 53 (segurança). Sugestão: incluir como parágrafo do art. 59 em aditivo.

## 12. Documentos ilegíveis / a conferir
- `Taxa Condiminial na Locação.pdf` (pasta DOC's, 09/2026): PDF de imagem, sem texto — pedir cópia legível ou rodar OCR.
- `1 de dez. 20.00.m4a`: gravação da AGO de 01/12/2025 (áudio, não transcrito).
- Proprietário do 310: planilha indica Claudinei Ribeiro de Lima Junior (entrada 30/01/2026), mas o pagamento de 10/2026 de Luciane Moro inclui "apto 310"; relatório de água de 10/2026 traz Kauam Teixeira Taborba como responsável. Confirmar.

## 13. Referências legais úteis
- CC 1.331 § 1º: vaga de garagem não pode ser alienada/alugada a estranho ao condomínio sem autorização expressa na convenção.
- CC 1.335: direitos (usar, votar se quite). CC 1.336: deveres; § 1º juros/multa; § 2º multa até 5×.
- CC 1.337: multa até 5× (3/4) e 10× (antissocial). STJ exige direito de defesa prévio antes da multa do 1.337 (REsp 1.365.279/SP).
- CC 1.341: obras — voluptuárias 2/3, úteis maioria, necessárias o síndico pode fazer.
- CC 1.345: adquirente responde pelos débitos do alienante.
- CC 1.347–1.349: síndico (mandato até 2 anos; destituição pela maioria absoluta).
- CC 1.350: AGO anual obrigatória. CC 1.351: 2/3 para alterar a convenção (regimento: conforme a convenção, desde a Lei 10.931/2004); unanimidade para mudar destinação.
- CC 1.352–1.355: votos, convocação de todos, 2ª convocação, AGE por 1/4.
- Lei 8.245/91 art. 23 XII: locatário paga as despesas ordinárias; art. 22 X: locador paga as extraordinárias (pintura de fachada, fundo de reserva para obras etc.).

## 14. Fundo de pintura (validação de 19/11/2026)
Planilha `London-Residence/Validacao_Fundo_Pintura_2023-2026.xlsx`. Previsto pelas atas (05/2023–11/2026): R$ 87.100 (R$ 86.600 pela planilha do Drive — diferença de R$ 500 na competência 12/2023, que a ata manda cobrar a R$ 70). Saídas lançadas: R$ 86.768,42 (2024: R$ 10.850; 2026: fachada Santos Aleluia R$ 47.500, Fidelidade Drywall R$ 26.680, tinta R$ 1.600, R$ 138,42 a confirmar). Fachada paga R$ 2.500 acima do contrato (R$ 45.000). Fidelidade Drywall sem NF nem contrato localizados. Recebido real só pelo AcolWeb.
